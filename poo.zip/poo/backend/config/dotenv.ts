import { config } from "dotenv";

config(); // Carrega as variáveis do .env
console.log("Variáveis de ambiente carregadas.");
